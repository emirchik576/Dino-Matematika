ДИНО-МАТЕМАТИКА — проект Android-приложения

Важно: это исходный проект Android Studio, а не готовый APK-файл.
Собрать APK можно на компьютере с Android Studio. Сам проект не требует
дополнительных библиотек, но Android Studio скачает Gradle и Android SDK.

Как собрать:
1. Установить Android Studio с официального сайта developer.android.com/studio.
2. Открыть в Android Studio папку DinoMathAndroid.
3. Дождаться окончания Gradle Sync.
4. Выбрать Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Нажать Locate в уведомлении сборки — там будет app-debug.apk.
6. Передавать APK на телефон только со своего компьютера и устанавливать,
   если доверяете источнику.

Игра загружается из app/src/main/assets/index.html.
Она использует внешние CDN для оформления, шрифтов и звуковых библиотек,
поэтому для полной работы этих элементов нужен интернет.
